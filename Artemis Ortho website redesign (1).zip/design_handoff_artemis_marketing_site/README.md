# Handoff: Artemis Ortho App — Marketing Website (v4, value/savings-led)

## Overview
Marketing/landing site for **Artemis Ortho App** (artemisorthoapp.com) — an all-in-one
practice-management platform for orthodontic practices that **replaces 15+ separate tools**
(analytics, patient communication, social, SEO, reviews, financials, insurance verification,
inventory, HR/training, AI assistant, HIPAA compliance) with one system.

The page is **value- and savings-led**: it opens with the cost problem, lets the visitor
calculate their own current spend, then shows the product that consolidates it. Primary
goal: **Request a demo** (lead capture → the practice's team follows up).

Tone: confident, modern, clean — "we simplify your life," never "your tools suck."

## About the Design Files
`Artemis Ortho Website v4.dc.html` is a **design reference built in HTML** — a working,
interactive prototype of the intended look, motion, and behavior. It is **not production
code to copy verbatim.** The `.dc.html` format is a self-contained component used by the
design tool (markup + a `class Component` logic block at the bottom).

Recreate this in the target environment: the live site is an **Astro** project
(`artemisorthoapp/aso_public`, deployed on Cloudflare Pages; lead endpoint is the Pages
Function `functions/api/trial.js`). Rebuild these sections as Astro/React components using
that repo's patterns. Any modern framework is fine if rebuilt elsewhere — match the spec.

## Fidelity
**High-fidelity.** Colors, type, spacing, copy, the calculator logic, and the headline
numbers are all final and present in the prototype. Recreate pixel-accurately.

## Brand & Design Tokens
- **Primary / Navy:** `#1B1A22` (dark sections, ink). Deeper variant `#14121A`; footer `#0F0E14`.
- **Accent / Teal:** `#14B8A6` (CTAs, accents, highlights). Darker teal `#0F766E`; light `#5EEAD4`.
- **Light surfaces:** page `#FFFFFF`, muted panels `#F7F8F9`; borders `#E8EAED`/`#EBEDF0`.
- **Text:** ink `#1B1A22`, body `#5A6072`, muted `#9CA3AF`.
- **Type:** headings **Philosopher** 700; body/UI **Karla** 300–800 (buttons Karla 800).
  Google Fonts: `Philosopher:wght@400;700` + `Karla:wght@300;400;500;600;700;800`.
- **Shape:** pill buttons `border-radius:980px`; cards 14–20px; section padding ~110px;
  content max-width 1080–1180px. Card shadow `0 18px 50px rgba(27,26,34,0.06)`.

> Note: this design system also ships an Artemis component library (`window.ArtemisDS`,
> Philosopher/Karla, `--brand-*` teal scale, `btn`/`input` classes, KpiCard/Badge/DataTable
> etc.) at `_ds/artemis-ortho-app-design-system-019df5ea-…/`. The production rebuild should
> prefer those primitives where they fit (buttons, inputs, KPI tiles) rather than re-styling
> raw elements.

## Headline numbers (researched — use exactly)
- **15+** tools replaced · **21** background jobs running 24/7 · **80+** staff hours/month
  saved · **20+** integrations connected · **$49,800–99,000/yr** combined value.

## Sections (single long-scroll page, top → bottom)
1. **Fixed nav** — mark + "Artemis Ortho App" wordmark; links Calculator / What we replace /
   Product / Pricing; teal "Request demo" pill. Links hide < 720px.
2. **Hero** (navy, animated teal mesh blobs) — eyebrow "ONE PLATFORM · 15+ TOOLS REPLACED",
   H1 "Your whole practice, on one platform.", subcopy, and an **animated savings counter**
   that counts up (ease-out cubic, ~1.6s) to the calculator's annual total. Two CTAs:
   Request a demo (→ #demo) and Calculate your savings (→ #calculator).
3. **Stats band** (near-black) — the four headline numbers (15+/21/80+/20+).
4. **Value calculator** (#calculator) — THE interactive centerpiece. A checklist of **11
   tool categories**, each with an example vendor and a monthly cost; the visitor unchecks
   what they don't use and a **sticky result panel** recomputes **"You pay today $X/mo ≈
   $Y/yr across N tools"** live, contrasted with "Artemis replaces all of it" and a
   "$49,800–99,000/yr typical savings" chip. (Default: all 11 checked.)
5. **What we replace** (#replace) — 11-category grid, each "old vendor → Artemis."
6. **Integrations** (dark) — auto-scrolling marquee of integration name chips (Cloud 9,
   QuickBooks, Meta, Google, Twilio, Stedi, Stripe, Canva, HeyGen, Paychex, Birdeye, …).
7. **Product — 5 verbs** (#product) — Today (featured wide card) / People / Growth / Money /
   Operations, each with a real dashboard screenshot + summary. (Copy in prototype.)
8. **Testimonial** — Dr. Bennie, Artemis Smiles Orthodontics (visibility + productive team +
   cancelled subscriptions).
9. **Demo / pricing CTA** (#demo) — "One platform fee. Everything included." + the lead form.
10. **Footer.**

### Calculator cost model (per month, editable in the logic class)
analytics 500 · patient comm 600 · social 800 · SEO 1000 · reviews 400 · financials 700 ·
insurance 500 · inventory 250 · HR/payroll 350 · AI 300 · HIPAA 400 → **$5,800/mo ≈
$69,600/yr** all-checked (lands inside the researched $49,800–99,000 range). These are
representative placeholders — tune to your own benchmarks.

## The 5-verb product architecture (exact)
1. **Today** — AI morning briefing, persona-based KPIs, Ask Artemis voice assistant.
2. **People** — treatment funnel, patient detail, scheduling, communication, insurance,
   aligner cases.
3. **Growth** — social calendar + AI posting, SEO, leads, reviews, blog generation,
   sponsorships.
4. **Money** — QuickBooks, auto close reports, AR aging, production vs. targets.
5. **Operations** — inventory with QR scanning, employee reviews, training, payroll,
   practice manuals.

## Interactions & Behavior
- **Savings counter:** `requestAnimationFrame` count-up to the annual total on load.
- **Calculator:** click a row to toggle; React state recomputes monthly/annual totals and
  selected count; checkbox/affordance colors flip teal↔gray. Result panel is `position:sticky`.
- **Integrations marquee:** JS duplicates the track and translates X for a seamless loop.
- **Scroll reveal:** `.rev` elements fade/translate up via IntersectionObserver (one-shot).
- **Smooth scroll** to in-page anchors.

## Lead form — wiring (IMPORTANT, matches the real endpoint)
The form posts the **exact fields `functions/api/trial.js` expects**:
`first_name`, `last_name`, `practice`, `email` (all required), `phone` (optional),
a hidden `plan=growth`, and a hidden honeypot `company_website` (must stay empty).

**Submission behavior in the prototype (intentional):** JavaScript intercepts submit,
`preventDefault()`s, sends the data to `/api/trial` in the background via `fetch` with a
`FormData` body (so `request.formData()` parses it server-side), then shows an **inline
"we'll reach out shortly to set up your demo" confirmation** — the visitor is **NOT**
redirected anywhere. This is a deliberate product decision: **leads are contacted by the
Artemis team; visitors are not pushed into the app's login/signup.**

To make leads actually arrive on the live site:
- Set **`LEAD_WEBHOOK_URL`** in the Cloudflare Pages environment (Slack/Zapier/Make/CRM).
  `trial.js` forwards each validated lead there.
- The stock `trial.js` also does a 303 **redirect** to the app signup. Since the prototype
  intentionally suppresses that (background fetch, no navigation), either keep the JS
  intercept in production, or have `trial.js` return a 200/JSON instead of a redirect for
  this form. **Do not restore the auto-redirect** unless the team changes its mind.
- `phone` is currently **ignored** by `trial.js`. To capture it, add
  `phone: str("phone")` to the `lead` object (and include it in the webhook payload).

## State Management
- `checked: {category: boolean}` — calculator selections (all true by default).
- `submitted: boolean` — toggles the inline thank-you + button label after submit.
- No data fetching for page render; the only network call is the background lead POST.

## Responsive
Fluid `clamp()` type throughout. `@media` breakpoints: ≤980px calculator/verb/category grids
→ 1 col; ≤720px nav links hide, stats → 2 col, hero CTAs + form rows stack; ≤460px stats and
name row → 1 col. Practice owners browse on phones — verify the calculator + form on mobile.

## Assets
- Real, PHI-free dashboard screenshots (1440×900) under `assets/gallery/` (sourced from
  `artemisorthoapp/aso_public` → `design-assets/dashboard-frames/gallery/`).
- Logos under `assets/`: `mark.png`, `mark-white.png`, `logo-horizontal.png`, `favicon.png`.
- Integration "logos" are rendered as **text chips** in the prototype — swap for real SVG
  logos in production if desired.
- Fonts from Google Fonts (Philosopher, Karla).

## Files in this package
- `Artemis Ortho Website v4.dc.html` — the editable design prototype (source of truth).
- `Artemis Ortho Website v4 (standalone).html` — single self-contained file (fonts + all
  images inlined) that opens offline in any browser, for stakeholder review.
- `assets/` — images used by the prototype.
