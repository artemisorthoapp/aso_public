# Handoff: Artemis Ortho App — Marketing Website (Apple-style)

## Overview
A long-scroll marketing/landing site for **Artemis Ortho App** — an official Cloud 9
Ortho partner that reads a practice's Cloud 9 data overnight, automates busywork on a
schedule, and briefs every role each morning. The site is modeled on apple.com (and
specifically apple.com/os/ios + apple.com/apple-intelligence): a self-playing full-bleed
product "film," scroll-reveal feature storytelling, a dark automations spotlight, a
drag-scroll product gallery, results stats, and a free-signup CTA.

Goal of the page: explain the product, showcase features (with emphasis on **automation +
total visibility**), and drive **"Sign up free"** demo signups.

## About the Design Files
The file in this bundle (`Artemis Ortho Website v2.dc.html`) is a **design reference
created in HTML** — a working prototype showing the intended look, motion, and behavior.
It is **not production code to copy directly**. The `.dc.html` format is a self-contained
component used by the design tool; treat it as a high-fidelity spec.

The task is to **recreate this design in the target codebase's environment**. The live
marketing site is an **Astro** project (`artemisorthoapp/aso_public`, deployed on
Cloudflare; signup posts to `/api/trial`). Implement these screens as Astro/React
components using that repo's existing patterns, fonts, and tokens. If rebuilding
elsewhere, any modern framework is fine — match the visual spec below pixel-for-pixel.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, motion, and copy are all
specified here and present in the prototype. Recreate pixel-accurately.

## Brand & Design Tokens

### Colors (official 2024 brand palette)
| Token | Hex | Use |
|---|---|---|
| Black | `#24232D` | Primary ink / headlines |
| Charcoal | `#494E63` | Secondary text, nav links |
| Slate Purple | `#696C8B` | Tertiary accents |
| Verdigris | `#67A4A1` | **Primary brand** — buttons, accents |
| Robin Egg Blue | `#69C9CC` | Bright accent, eyebrows on dark |
| Persian Pink | `#ED83D1` | **Call-to-action / highlight only** |
| Cloud | `#F2F0F3` | Light neutral surface |
| White | `#FFFFFF` | Base background |

Supporting values used in the prototype: body text `#5A6072`; muted `#6B7280` / `#9CA3AF`;
light teal tint `#E0F5F5`; dark sections `#16161C` and `#0E0E12` (footer `#0A0A0D`);
hero gradient wash `linear-gradient(180deg,#F4FBFB,#EAF6F6 46%,#fff)`; card border `#ECECEF`.

### Typography
- **Headings:** `Philosopher`, weight 700 (Bold). Used for all H1–H3, stat numbers, captions.
- **Body / UI:** `Karla`, weights 300–800. Buttons are Karla **Extra-Bold (800)**.
- Google Fonts: `Philosopher:wght@400;700` + `Karla:wght@300;400;500;600;700;800`.
- Headline sizing is fluid: H1 `clamp(44px,7.4vw,88px)`, line-height ~1.0,
  letter-spacing `-0.025em`. Section H2 `clamp(30px,5vw,54px)`. Feature H3 ~34px.
- Eyebrows: 12–13px, weight 800, letter-spacing `.06em–.12em`, UPPERCASE.

### Spacing / radius / shadow
- Section vertical padding: ~110–130px (desktop).
- Content max-width: `1120px` (gallery/nav), `1080px` (text sections), `560px` (form).
- Pill buttons: `border-radius: 980px`, padding `13px 28px` (primary) / `7px 16px` (nav).
- Cards / media frames: `border-radius: 14–18px`.
- Card shadow: `0 30px 70px rgba(36,35,45,0.14)`; hero/dark media `0 50px 110px rgba(0,0,0,0.5)`.
- Icon chips: 44–46px square, `border-radius: 12–13px`, bg `#E0F5F5`, glyph `#67A4A1`.

## Screens / Views (single long-scroll page, top → bottom)

### 1. Fixed Nav
- Fixed top, height 54px, `backdrop-filter: blur(20px)`, bg `rgba(255,255,255,0.78)`,
  1px bottom border `rgba(36,35,45,0.07)`. Max-width 1120, 24px side padding.
- Left: mark logo (`assets/mark.png`, 26px tall) + wordmark "Artemis **Ortho App**"
  (Philosopher 700, 17px; "Ortho App" in Verdigris).
- Right: text links **Automations · Features · Product** (Karla 600, 13px, `#494E63`) +
  **Sign up free** pill (bg Verdigris, white, Karla 800, 13px).
- Responsive: the three text links hide below 720px; the Sign-up pill always shows.

### 2. Hero (text band)
- Light gradient background with two animated blurred radial "mesh" blobs
  (Verdigris + faint Persian Pink), slow drift (`@keyframes ao-mesh/ao-mesh2`, 20–24s).
- Centered, max-width 920. Contents (each fades up on load via `.ao-rev`):
  - Eyebrow pill: "● OFFICIAL CLOUD 9 ORTHO PARTNER" (white pill, Verdigris dot+text).
  - H1: "Total visibility." + line break + "Automatic everything." — the second line is a
    gradient text fill `linear-gradient(120deg,#67A4A1,#69C9CC 55%,#ED83D1)`.
  - Sub (17–22px, `#5A6072`, max-width 680): "Artemis reads your Cloud 9 data overnight,
    runs the busywork on a schedule, and briefs every role each morning on the few things
    that need a human. One calm surface for the whole practice."
  - Two buttons: **Sign up free** (Verdigris pill → #demo) and **Take the tour ↓**
    (white pill, 1px border → #features).

### 3. Full-bleed Autoplay Film (the "video") — signature element
- A **frameless, edge-to-edge** section (full viewport width, no browser chrome),
  container `aspect-ratio: 1440/900`, `max-height: 88vh`, bg `#0E0E12`.
- Five real app screenshots stacked absolutely, `object-fit: cover; object-position: top
  center`, cross-fading (`opacity` transition 1s). It **autoplays on a timer** (no scroll
  needed), advancing every **3600ms**, looping.
- The active image runs a slow **Ken-Burns** zoom: `@keyframes ao-ken { from
  transform:scale(1.015) translateY(0) → to scale(1.10) translateY(-3.5%) }` over dwell+900ms.
- Overlays: top-left **segmented progress bars** (5 segments; the active one fills 0→100%
  over the dwell, past ones stay full) + top-right **LIVE** pill (blurred dark chip, pulsing
  Persian-Pink dot). Bottom **caption** over a dark gradient: an eyebrow (verb, Robin-Egg)
  + a Philosopher title that swaps per slide.
- Slide order & captions:
  1. **Today** — "Every morning, the briefing that needs you." (`01-today.jpg`)
  2. **People** — "The full treatment funnel, end to end." (`02-people-funnel.jpg`)
  3. **Growth** — "See exactly what drives new starts." (`08-growth.jpg`)
  4. **Money** — "Production, collections & AR — clear." (`16-money.jpg`)
  5. **Automations** — "The busywork runs itself, overnight." (`25-automations.jpg`)

### 4. Automations Spotlight (dark `#0E0E12`)
The emphasized section. Centered intro: eyebrow "AUTOMATIONS" (Persian Pink), H2 "The work
that used to wait for someone — now just happens.", sub about overnight schedules +
event-driven reminders + human-in-the-loop.
- Large **frameless** screenshot `25-automations.jpg` (Job Schedules) — rounded 16px,
  big shadow.
- Three pillars (3-col grid, collapses to 1 col ≤900px): **Scheduled jobs** (◷, Robin-Egg
  chip), **Event-driven reminders** (⚡, Persian-Pink chip), **Human in the loop** (✓,
  Verdigris chip) — each a translucent card with title + paragraph (copy in prototype).
- Two-column block (collapses ≤900px): left copy "It notices, so your front desk doesn't
  have to." + 3 pulsing-dot bullets (Insurance Auto-Update · Patient Info Update Summary ·
  Inventory Cycle Count Completed); right the `24-operations-reminders.jpg` screenshot.

### 5. Features — five verbs (white)
Centered intro: eyebrow "TOTAL VISIBILITY", H2 "Five verbs. One practice, in focus.", sub.
Then **five alternating two-column rows** (`.feat-grid`, image left/right alternating;
collapses to single column ≤900px, image stacks under copy). Each row: eyebrow + H3 +
paragraph + three checkmark bullets (teal `#E0F5F5` ✓ chips) on one side, and on the other
a screenshot inside a **light browser frame** (34px top bar with 3 traffic-light dots,
rounded 14px, soft shadow):
  1. **Today** (pink eyebrow) — "A briefing that thinks for you." — `01-today.jpg`
  2. **People** (teal) — "The treatment funnel, end to end." — `02-people-funnel.jpg`
  3. **Growth** (teal) — "Know what actually drives starts." — `08-growth.jpg`
  4. **Money** (teal) — "Production, collections, and AR — straight." — `16-money.jpg`
  5. **Operations** (pink) — "Chairs, team, and the whole back office." — `19-operations.jpg`
(Exact bullet copy is in the prototype.)

### 6. Product Gallery (dark `#16161C`)
Eyebrow "EXPLORE THE PRODUCT", H2 "Thirty screens. One source of truth.", sub "Drag to
explore real screens from the live app." Then a **horizontal drag/scroll rail** (`#hl-rail`,
`overflow-x:auto; scroll-snap-type:x mandatory`, hidden scrollbar) of screenshot cards
(each `clamp(280px,72vw,520px)` wide, light browser frame, label under). Cards:
Social planner (`09`), Insurance eligibility (`06`), Financials (`17`), Inventory (`20`),
Snap→Canva (`28`), SEO (`11`), Payroll (`22`).

### 7. "And so much more" chiclet grid (white)
H2 "Working quietly underneath. **And so much more.**" (second clause in `#9CA3AF`).
3-col grid (→ 2-col ≤720px, → 1-col ≤460px) of 6 icon+title+paragraph chiclets:
Automated eligibility, Day & month close, A briefing per role, Records & photo upload,
Built for patient data, Live in days not quarters.

### 8. Results (light teal `#F4FBFB`)
Eyebrow "THE PAYOFF", H2 "Hours back. Nothing slipping through.", then a 3-col stat row
(→ 1-col ≤720px): **6+** hours automated weekly · **5** verbs on one screen · **0** nightly
spreadsheets/manual calls/double entry. Stat numbers Philosopher 700, `clamp(48px,7vw,64px)`,
Verdigris.

### 9. Demo / Signup (dark `#0E0E12`)
Animated teal mesh glow. Centered max-width 560. H2 "Start with tomorrow's briefing.", sub,
then a form: row of **First name** + **Practice name** (2-col, stacks ≤460px), **Work email**
(full), and submit button **"Sign up free"** (Verdigris, Karla 800). On submit the button
label swaps to "✓ Thanks — check your inbox" (prototype prevents default; wire to the real
`/api/trial` endpoint). Fine print about Cloud 9 partnership + control of patient messages.

### 10. Footer (near-black `#0A0A0D`)
Mark-white logo + wordmark, link row (Automations/Features/Product/Sign up), copyright.
Row stacks vertically ≤720px.

## Interactions & Behavior
- **Autoplay film:** `setInterval` every 3600ms advances index `(i+1)%5`; sets active img
  opacity 1 (others 0), restarts Ken-Burns animation, animates the active progress segment
  width 0→100% over the dwell, and cross-fades the caption eyebrow/title (150ms swap).
  Loops forever; requires no user input.
- **Scroll reveal:** elements with class `.ao-rev` start `opacity:0; translateY(40px)` and
  transition to visible via an `IntersectionObserver` (threshold 0.12, rootMargin
  `0px 0px -8% 0px`), adding class `.ao-in`. One-shot (unobserve after reveal).
- **Gallery rail:** native horizontal scroll + `scroll-snap`. Drag/trackpad/touch.
- **Buttons/anchors:** in-page smooth scroll (`html{scroll-behavior:smooth}`) to
  `#automations / #features / #gallery / #demo`.
- **Form:** client-side only in the prototype (sets a `submitted` state). Replace with a
  POST to `/api/trial` (fields: first name, practice name, work email).
- **Animations/keyframes:** `ao-mesh`/`ao-mesh2` (blob drift), `ao-ken` (Ken Burns),
  `ao-pulse` (LIVE/status dots), `ao-float` (subtle hover, used sparingly). All ease-in-out.

## State Management
- `submitted: boolean` — toggles the signup button label after submit.
- Film index — internal to the autoplay timer (not React state; direct DOM opacity/width).
- No data fetching in the prototype; real build fetches nothing for the page itself and
  POSTs the signup form to `/api/trial`.

## Responsive behavior
- Fluid type via `clamp()` throughout; nothing is fixed-px for headlines.
- `@media (max-width:900px)`: feature rows + automations 2/3-col grids collapse to 1 col.
- `@media (max-width:720px)`: nav text links hide; chiclet grid → 2 col; stats → 1 col;
  footer stacks.
- `@media (max-width:460px)`: chiclet grid → 1 col; signup name/practice row → 1 col.
- The film is `width:100%` with `aspect-ratio:1440/900` so it scales fluidly edge-to-edge.

## Assets
All screenshots are **real, PHI-free** captures of the live Artemis dashboard (1440×900),
sourced from `artemisorthoapp/aso_public` → `design-assets/dashboard-frames/gallery/`.
Bundled here under `assets/gallery/` (30 screens, `01-today.jpg` … `30-marketing.jpg`).
Logos under `assets/`: `mark.png`, `mark-white.png`, `logo-horizontal.png`, `favicon.png`.
Replace placeholder names/figures in screenshots as desired — they are demo data.
Fonts load from Google Fonts (Philosopher, Karla).

## Files
- `Artemis Ortho Website v2.dc.html` — the full design prototype (markup + the autoplay /
  reveal logic at the bottom in a `class Component`). This is the single source of truth for
  layout, copy, colors, and motion.
- `assets/` — all images used by the prototype.
